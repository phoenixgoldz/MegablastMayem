public class Main extends GameLauncher {


    public Main(int num) {
        super(num);
    }
}
