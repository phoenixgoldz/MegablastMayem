public enum SubMenu {
    NONE,
    HOW_TO_PLAY,
    CONTROLS
}
